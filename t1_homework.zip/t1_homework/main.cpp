#include<iostream>
#include<cmath>

#include <Eigen/Core>
#include<Eigen/Geometry>
 
#include "sophus/so3.h"
#include "sophus/se3.h"


using namespace std;

int main(int argc, char** argv)
{   //可改变输入旋转矩阵
    Eigen::Matrix3d R = Eigen::AngleAxisd(M_PI/4, Eigen::Vector3d(1,1,0)).matrix();
    Sophus::SO3 SO3(R);
   
    //so3更新
    Eigen::Vector3d update_so3(0.01, 0.02, 0.03); //假设更新量为这么多
    Sophus::SO3 SO3_updated = SO3*Sophus::SO3::exp(update_so3);
    cout<<"SO3 updated = "<<endl<<SO3_updated.matrix()<<endl;
    //四元数更新
     Eigen::Quaterniond q(R);
     Eigen::Quaterniond update_q(1,0.005,0.01,0.015); 
     Eigen::Quaterniond q_u= q*update_q;
    
    //××××××只有单位四元数才表示旋转矩阵，所以要先对四元数做单位化××××××××
     q.normalized();	
     Eigen::Matrix3d q_R=q.toRotationMatrix();
     
     cout<<"Quat updated = " <<endl<< q_R<<endl;
    return 0;        
}